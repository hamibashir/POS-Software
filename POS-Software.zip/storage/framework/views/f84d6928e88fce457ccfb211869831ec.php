<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'POS'); ?> — HardwarePro</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --pos-primary:    #1a6b7c;
            --pos-primary-dk: #0d4a57;
            --pos-primary-lt: #e8f4f7;
            --pos-bar-h:      52px;
        }
        * { font-family: 'Inter', sans-serif; box-sizing: border-box; }
        body { background: #f0f2f5; margin: 0; overflow: hidden; height: 100vh; }

        /* ── Top bar ────────────────────────── */
        .pos-bar {
            height: var(--pos-bar-h);
            background: var(--pos-primary);
            display: flex; align-items: center;
            padding: 0 20px; gap: 12px;
            position: fixed; top: 0; left: 0; right: 0; z-index: 100;
        }
        .pos-bar .brand { color: #fff; font-weight: 700; font-size: 15px; display:flex; align-items:center; gap:6px; }
        .pos-bar .clock { color: rgba(255,255,255,.75); font-size: 13px; margin-left: auto; }
        .pos-bar .cashier-name { color: rgba(255,255,255,.85); font-size: 13px; display:flex; align-items:center; gap:6px; }
        .pos-bar .btn-admin-back {
            background: rgba(255,255,255,.15); color:#fff; border: 1px solid rgba(255,255,255,.3);
            border-radius:6px; padding: 4px 12px; font-size:12px; text-decoration:none;
            transition: background .15s;
        }
        .pos-bar .btn-admin-back:hover { background: rgba(255,255,255,.25); }

        /* ── Logout form ─────────────────────── */
        .pos-bar form { margin: 0; }
        .pos-bar .btn-logout-sm {
            background:rgba(255,255,255,.15); color:#fff; border:1px solid rgba(255,255,255,.3);
            border-radius:6px; padding:4px 10px; font-size:12px; cursor:pointer; transition: background .15s;
        }
        .pos-bar .btn-logout-sm:hover { background:rgba(255,255,255,.25); }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<div class="pos-bar">
    <div class="brand"><i class="bi bi-tools"></i> HardwarePro POS</div>

    <?php if(auth()->user()->isAdmin()): ?>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-admin-back">
            <i class="bi bi-shield-check me-1"></i>Admin
        </a>
    <?php endif; ?>

    <span class="clock" id="posClock">--:--:--</span>

    <div class="cashier-name ms-3">
        <i class="bi bi-person-badge"></i>
        <?php echo e(auth()->user()->name); ?>

    </div>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn-logout-sm">
            <i class="bi bi-box-arrow-right"></i> Logout
        </button>
    </form>
</div>

<?php echo $__env->yieldContent('content'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Live clock
    function updateClock() {
        const now = new Date();
        document.getElementById('posClock').textContent = now.toLocaleTimeString();
    }
    updateClock();
    setInterval(updateClock, 1000);
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/layouts/cashier.blade.php ENDPATH**/ ?>