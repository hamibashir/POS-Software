
<?php $__env->startSection('title', 'Stock Adjustments'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .filter-card { background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:14px 18px; margin-bottom:18px; }
    .filter-card form { display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end; }
    .filter-card .fg { display:flex; flex-direction:column; gap:4px; }
    .filter-card label { font-size:11px; font-weight:600; color:#6b7280; text-transform:uppercase; letter-spacing:.6px; }
    .badge-in  { background:#d1fae5; color:#065f46; border-radius:20px; padding:3px 10px; font-size:11px; font-weight:700; }
    .badge-out { background:#fee2e2; color:#991b1b; border-radius:20px; padding:3px 10px; font-size:11px; font-weight:700; }
    .mono { font-family:monospace; font-size:12px; color:#374151; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-hero d-flex align-items-center justify-content-between">
    <div>
        <h1><i class="bi bi-arrow-left-right me-2" style="color:var(--pos-primary)"></i>Stock Adjustments</h1>
        <p>Manual inventory increases and decreases with reason tracking.</p>
    </div>
    <a href="<?php echo e(route('admin.stock.create')); ?>" class="btn-pos text-decoration-none">
        <i class="bi bi-plus-circle"></i> New Adjustment
    </a>
</div>

<?php if(session('success')): ?>
<div class="pos-alert pos-alert-success mb-3">
    <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<div class="filter-card">
    <form method="GET" action="<?php echo e(route('admin.stock.index')); ?>">
        <div class="fg" style="flex:2;min-width:200px;">
            <label>Search Product</label>
            <div style="position:relative;">
                <i class="bi bi-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#9ca3af;"></i>
                <input type="text" name="search" class="pos-input" style="padding-left:34px;"
                    value="<?php echo e(request('search')); ?>" placeholder="Product name or SKU…">
            </div>
        </div>
        <div class="fg">
            <label>From</label>
            <input type="date" name="date_from" class="pos-input" value="<?php echo e(request('date_from')); ?>" style="width:150px;">
        </div>
        <div class="fg">
            <label>To</label>
            <input type="date" name="date_to" class="pos-input" value="<?php echo e(request('date_to')); ?>" style="width:150px;">
        </div>
        <div class="fg">
            <label>Type</label>
            <select name="type" class="pos-input" style="width:140px;">
                <option value="">All</option>
                <option value="adjustment_in"  <?php echo e(request('type') === 'adjustment_in'  ? 'selected' : ''); ?>>Stock In  (+)</option>
                <option value="adjustment_out" <?php echo e(request('type') === 'adjustment_out' ? 'selected' : ''); ?>>Stock Out (−)</option>
            </select>
        </div>
        <div class="fg">
            <label>&nbsp;</label>
            <div style="display:flex;gap:8px;">
                <button type="submit" class="btn-pos"><i class="bi bi-funnel"></i> Filter</button>
                <a href="<?php echo e(route('admin.stock.index')); ?>" class="btn-pos-outline text-decoration-none"><i class="bi bi-x"></i></a>
            </div>
        </div>
    </form>
</div>

<div class="pos-card">
    <?php if($movements->isEmpty()): ?>
        <div style="padding:60px;text-align:center;color:#9ca3af;">
            <i class="bi bi-arrow-left-right" style="font-size:48px;display:block;margin-bottom:12px;"></i>
            <p style="font-size:15px;font-weight:600;">No adjustments recorded yet</p>
            <a href="<?php echo e(route('admin.stock.create')); ?>" style="color:var(--pos-primary);">Create your first adjustment →</a>
        </div>
    <?php else: ?>
    <table class="pos-table w-100">
        <thead>
            <tr>
                <th>Date</th>
                <th>Product</th>
                <th>Type</th>
                <th>Qty</th>
                <th>Before</th>
                <th>After</th>
                <th>Reason / Notes</th>
                <th>By</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div style="font-weight:600;font-size:13px;"><?php echo e($m->created_at->format('d M Y')); ?></div>
                    <div style="font-size:11px;color:#9ca3af;"><?php echo e($m->created_at->format('g:i A')); ?></div>
                </td>
                <td>
                    <div style="font-weight:600;"><?php echo e($m->product?->name ?? '—'); ?></div>
                    <div class="mono"><?php echo e($m->product?->sku); ?></div>
                </td>
                <td>
                    <?php if($m->type === 'adjustment_in'): ?>
                        <span class="badge-in">⬆ Stock In</span>
                    <?php else: ?>
                        <span class="badge-out">⬇ Stock Out</span>
                    <?php endif; ?>
                </td>
                <td style="font-weight:700;font-size:15px;">
                    <?php echo e($m->type === 'adjustment_in' ? '+' : '−'); ?><?php echo e($m->quantity); ?>

                </td>
                <td style="color:#9ca3af;"><?php echo e($m->stock_before); ?></td>
                <td style="font-weight:600;color:<?php echo e($m->type === 'adjustment_in' ? '#065f46' : '#991b1b'); ?>;">
                    <?php echo e($m->stock_after); ?>

                </td>
                <td style="font-size:13px;color:#374151;max-width:280px;"><?php echo e($m->notes); ?></td>
                <td style="font-size:13px;"><?php echo e($m->user?->name ?? '—'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if($movements->hasPages()): ?>
    <div style="padding:16px 20px;border-top:1px solid #f3f4f6;"><?php echo e($movements->links()); ?></div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/admin/stock/index.blade.php ENDPATH**/ ?>