

<?php $isEdit = isset($product) && $product->exists; ?>


<?php if($errors->any()): ?>
    <div class="pos-alert pos-alert-error mb-4">
        <i class="bi bi-exclamation-circle-fill fs-5"></i>
        <div>
            <strong>Please fix the following errors:</strong>
            <ul class="mb-0 mt-1 ps-3">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="font-size:13px;"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>

<div class="row g-4">

    
    <div class="col-lg-8">

        
        <div class="pos-card p-4 mb-4">
            <h6 class="fw-bold mb-4" style="color:#374151; font-size:14px;">
                <i class="bi bi-info-circle me-2" style="color:var(--pos-primary)"></i>Basic Information
            </h6>

            
            <div class="mb-3">
                <label class="form-label fw-semibold" style="font-size:13px;">
                    Product Name <span class="text-danger">*</span>
                </label>
                <input type="text" name="name" id="productName"
                    value="<?php echo e(old('name', $product->name ?? '')); ?>"
                    class="pos-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="e.g. Bosch 18V Cordless Drill"
                    required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold" style="font-size:13px;">
                        SKU <span class="text-danger">*</span>
                        <button type="button" id="generateSkuBtn"
                            class="btn btn-link p-0 ms-2" style="font-size:11px; color:var(--pos-primary); text-decoration:none;">
                            <i class="bi bi-arrow-clockwise"></i> Generate
                        </button>
                    </label>
                    <input type="text" name="sku" id="skuInput"
                        value="<?php echo e(old('sku', $product->sku ?? ($suggestedSku ?? ''))); ?>"
                        class="pos-input <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="e.g. PW-0042"
                        required>
                    <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold" style="font-size:13px;">Barcode (Optional)</label>
                    <input type="text" name="barcode"
                        value="<?php echo e(old('barcode', $product->barcode ?? '')); ?>"
                        class="pos-input <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Scan or type barcode">
                    <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="mb-0">
                <label class="form-label fw-semibold" style="font-size:13px;">Description</label>
                <textarea name="description" rows="3"
                    class="pos-input <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    style="resize:vertical;"
                    placeholder="Optional product description..."><?php echo e(old('description', $product->description ?? '')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="pos-card p-4 mb-4">
            <h6 class="fw-bold mb-4" style="color:#374151; font-size:14px;">
                <i class="bi bi-currency-dollar me-2" style="color:var(--pos-primary)"></i>Pricing & Unit
            </h6>

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label fw-semibold" style="font-size:13px;">
                        Unit <span class="text-danger">*</span>
                    </label>
                    <select name="unit" class="pos-input <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('unit', $product->unit ?? 'pc') === $value ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold" style="font-size:13px;">
                        Cost Price <span class="text-danger">*</span>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text" style="background:#f9fafb; border:1.5px solid #e5e7eb; border-right:none; border-radius:8px 0 0 8px; color:#6b7280; font-size:14px;">$</span>
                        <input type="number" name="cost_price" step="0.01" min="0"
                            value="<?php echo e(old('cost_price', $product->cost_price ?? '')); ?>"
                            class="pos-input <?php $__errorArgs = ['cost_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            style="border-radius:0 8px 8px 0; border-left:none;"
                            placeholder="0.00" required id="costPrice">
                    </div>
                    <?php $__errorArgs = ['cost_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold" style="font-size:13px;">
                        Sale Price <span class="text-danger">*</span>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text" style="background:#f9fafb; border:1.5px solid #e5e7eb; border-right:none; border-radius:8px 0 0 8px; color:#6b7280; font-size:14px;">$</span>
                        <input type="number" name="sale_price" step="0.01" min="0"
                            value="<?php echo e(old('sale_price', $product->sale_price ?? '')); ?>"
                            class="pos-input <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            style="border-radius:0 8px 8px 0; border-left:none;"
                            placeholder="0.00" required id="salePrice">
                    </div>
                    <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="mt-3 p-2 rounded" style="background:#f9fafb; font-size:13px; color:#6b7280;">
                <i class="bi bi-graph-up me-1"></i>
                Margin: <strong id="marginDisplay">—</strong>
            </div>
        </div>

        
        <div class="pos-card p-4">
            <h6 class="fw-bold mb-4" style="color:#374151; font-size:14px;">
                <i class="bi bi-layers me-2" style="color:var(--pos-primary)"></i>Stock Management
            </h6>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold" style="font-size:13px;">
                        Opening Stock Quantity <span class="text-danger">*</span>
                    </label>
                    <input type="number" name="stock_quantity" min="0"
                        value="<?php echo e(old('stock_quantity', $product->stock_quantity ?? 0)); ?>"
                        class="pos-input <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="0"
                        <?php echo e($isEdit ? 'disabled title=Use stock adjustment for edits' : 'required'); ?>>
                    <?php if($isEdit): ?>
                        <div style="font-size:12px; color:#9ca3af; margin-top:4px;">
                            <i class="bi bi-info-circle"></i> Use Purchase Entry to adjust stock after creation.
                        </div>
                    <?php endif; ?>
                    <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold" style="font-size:13px;">
                        Low Stock Alert Threshold <span class="text-danger">*</span>
                    </label>
                    <input type="number" name="low_stock_threshold" min="0"
                        value="<?php echo e(old('low_stock_threshold', $product->low_stock_threshold ?? 10)); ?>"
                        class="pos-input <?php $__errorArgs = ['low_stock_threshold'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="10" required>
                    <div style="font-size:12px; color:#9ca3af; margin-top:4px;">
                        Alert shown when stock falls at or below this number.
                    </div>
                    <?php $__errorArgs = ['low_stock_threshold'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

    </div>

    
    <div class="col-lg-4">

        
        <div class="pos-card p-4 mb-4">
            <h6 class="fw-bold mb-3" style="color:#374151; font-size:14px;">
                <i class="bi bi-tags me-2" style="color:var(--pos-primary)"></i>Category
            </h6>
            <select name="category_id" class="pos-input <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="">— Uncategorized —</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id', $product->category_id ?? '') == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="pos-card p-4 mb-4">
            <h6 class="fw-bold mb-3" style="color:#374151; font-size:14px;">
                <i class="bi bi-image me-2" style="color:var(--pos-primary)"></i>Product Image
            </h6>

            
            <div id="imagePreviewWrap" class="mb-3 text-center" style="<?php echo e(($isEdit && $product->image) ? '' : 'display:none;'); ?>">
                <img id="imagePreview"
                    src="<?php echo e($isEdit && $product->image ? Storage::url($product->image) : ''); ?>"
                    alt="Preview"
                    style="max-width:100%; max-height:180px; border-radius:10px; border:1px solid #e5e7eb; object-fit:contain;">
                <?php if($isEdit && $product->image): ?>
                    <div class="mt-2">
                        <label style="font-size:12px; color:#ef4444; cursor:pointer;">
                            <input type="checkbox" name="remove_image" value="1" id="removeImageCheck">
                            Remove current image
                        </label>
                    </div>
                <?php endif; ?>
            </div>

            
            <div id="uploadArea"
                onclick="document.getElementById('imageInput').click()"
                style="border:2px dashed #e5e7eb; border-radius:10px; padding:24px; text-align:center; cursor:pointer; transition:border-color .2s;">
                <i class="bi bi-cloud-upload" style="font-size:28px; color:#d1d5db;"></i>
                <p class="mb-0 mt-2" style="font-size:13px; color:#9ca3af;">Click to upload image</p>
                <p class="mb-0" style="font-size:11px; color:#d1d5db;">JPG, PNG, WebP — max 2MB</p>
            </div>
            <input type="file" name="image" id="imageInput" accept="image/*" class="d-none" onchange="previewImage(this)">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger mt-1" style="font-size:13px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="pos-card p-4 mb-4">
            <h6 class="fw-bold mb-3" style="color:#374151; font-size:14px;">
                <i class="bi bi-gear me-2" style="color:var(--pos-primary)"></i>Settings
            </h6>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="is_active" id="isActive" value="1"
                    <?php echo e(old('is_active', $product->is_active ?? true) ? 'checked' : ''); ?>>
                <label class="form-check-label fw-semibold" for="isActive" style="font-size:13px;">Active (available for sale)</label>
            </div>
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" name="show_in_catalog" id="showInCatalog" value="1"
                    <?php echo e(old('show_in_catalog', $product->show_in_catalog ?? true) ? 'checked' : ''); ?>>
                <label class="form-check-label fw-semibold" for="showInCatalog" style="font-size:13px;">Show in public catalog</label>
            </div>
        </div>

        
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn-pos-outline flex-fill text-center">
                <i class="bi bi-x-circle"></i> Cancel
            </a>
            <button type="submit" class="btn-pos flex-fill">
                <i class="bi bi-check-lg"></i> <?php echo e($submitLabel ?? 'Save Product'); ?>

            </button>
        </div>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // ── Image preview ────────────────────────────────
    function previewImage(input) {
        if (!input.files || !input.files[0]) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('imagePreview').src = e.target.result;
            document.getElementById('imagePreviewWrap').style.display = '';
            document.getElementById('uploadArea').style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }

    // ── Drag over upload area ─────────────────────────
    const uploadArea = document.getElementById('uploadArea');
    if (uploadArea) {
        uploadArea.addEventListener('dragover', (e) => { e.preventDefault(); uploadArea.style.borderColor = 'var(--pos-primary)'; });
        uploadArea.addEventListener('dragleave', ()  => { uploadArea.style.borderColor = '#e5e7eb'; });
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#e5e7eb';
            const input = document.getElementById('imageInput');
            input.files = e.dataTransfer.files;
            previewImage(input);
        });
    }

    // ── Margin calculator ────────────────────────────
    function updateMargin() {
        const cost = parseFloat(document.getElementById('costPrice').value) || 0;
        const sale = parseFloat(document.getElementById('salePrice').value) || 0;
        const el   = document.getElementById('marginDisplay');
        if (cost === 0 || sale === 0) { el.textContent = '—'; return; }
        const margin  = ((sale - cost) / sale * 100).toFixed(1);
        const profit  = (sale - cost).toFixed(2);
        const color   = margin >= 0 ? '#065f46' : '#991b1b';
        el.innerHTML  = `<span style="color:${color}">${margin}%</span> &nbsp;·&nbsp; $${profit} per unit`;
    }
    document.getElementById('costPrice').addEventListener('input', updateMargin);
    document.getElementById('salePrice').addEventListener('input', updateMargin);
    updateMargin();

    // ── SKU generator ────────────────────────────────
    document.getElementById('generateSkuBtn')?.addEventListener('click', async function () {
        const name = document.getElementById('productName').value || '';
        const res  = await fetch(`<?php echo e(route('admin.products.generate-sku')); ?>?name=${encodeURIComponent(name)}`);
        const data = await res.json();
        document.getElementById('skuInput').value = data.sku;
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/admin/products/_form.blade.php ENDPATH**/ ?>