

<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.stock-badge { padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }
.stock-in    { background: #d1fae5; color: #065f46; }
.stock-low   { background: #fef3c7; color: #92400e; }
.stock-out   { background: #fee2e2; color: #991b1b; }
.product-img { width: 44px; height: 44px; object-fit: cover; border-radius: 8px; border: 1px solid #e5e7eb; }
.product-img-placeholder { width: 44px; height: 44px; background: #f3f4f6; border-radius: 8px; display:flex; align-items:center; justify-content:center; border: 1px solid #e5e7eb; color:#d1d5db; font-size:18px; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<div class="page-hero d-flex align-items-start justify-content-between">
    <div>
        <h1><i class="bi bi-box-seam me-2" style="color:var(--pos-primary)"></i>Products</h1>
        <p>Manage your hardware store inventory, pricing, and stock levels.</p>
    </div>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn-pos">
        <i class="bi bi-plus-lg"></i> Add Product
    </a>
</div>


<?php if(session('success')): ?>
    <div class="pos-alert pos-alert-success mb-4"><i class="bi bi-check-circle-fill fs-5"></i> <?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="pos-alert pos-alert-error mb-4"><i class="bi bi-exclamation-circle-fill fs-5"></i> <?php echo e(session('error')); ?></div>
<?php endif; ?>


<div class="pos-card p-3 mb-4">
    <form method="GET" action="<?php echo e(route('admin.products.index')); ?>">
        <div class="d-flex gap-2 flex-wrap align-items-end">
            
            <div style="flex:2; min-width:220px;">
                <label class="form-label" style="font-size:12px; font-weight:600; color:#6b7280; margin-bottom:4px;">Search</label>
                <div class="input-group">
                    <span class="input-group-text" style="background:#f9fafb; border:1.5px solid #e5e7eb; border-right:none;"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                        class="pos-input" style="border-radius:0 8px 8px 0; border-left:none;"
                        placeholder="Name, SKU or barcode...">
                </div>
            </div>

            
            <div style="min-width:170px;">
                <label class="form-label" style="font-size:12px; font-weight:600; color:#6b7280; margin-bottom:4px;">Category</label>
                <select name="category_id" class="pos-input">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div style="min-width:140px;">
                <label class="form-label" style="font-size:12px; font-weight:600; color:#6b7280; margin-bottom:4px;">Status</label>
                <select name="status" class="pos-input">
                    <option value="">All Status</option>
                    <option value="active"   <?php echo e(request('status') === 'active'   ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>

            
            <div style="min-width:140px;">
                <label class="form-label" style="font-size:12px; font-weight:600; color:#6b7280; margin-bottom:4px;">Stock</label>
                <select name="stock" class="pos-input">
                    <option value="">All Stock</option>
                    <option value="in_stock" <?php echo e(request('stock') === 'in_stock' ? 'selected' : ''); ?>>In Stock</option>
                    <option value="low"      <?php echo e(request('stock') === 'low'      ? 'selected' : ''); ?>>Low Stock</option>
                    <option value="out"      <?php echo e(request('stock') === 'out'      ? 'selected' : ''); ?>>Out of Stock</option>
                </select>
            </div>

            <div class="d-flex gap-2" style="margin-top:20px;">
                <button type="submit" class="btn-pos"><i class="bi bi-funnel"></i> Filter</button>
                <?php if(request('search') || request('category_id') || request('status') || request('stock')): ?>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn-pos-outline"><i class="bi bi-x-circle"></i> Clear</a>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>


<div class="pos-card">
    <?php if($products->isEmpty()): ?>
        <div class="text-center py-5">
            <i class="bi bi-box-seam" style="font-size:48px; color:#d1d5db;"></i>
            <p class="mt-3 text-muted">No products found.
                <a href="<?php echo e(route('admin.products.create')); ?>">Add the first product.</a>
            </p>
        </div>
    <?php else: ?>
        <table class="table pos-table mb-0">
            <thead>
                <tr>
                    <th width="60">Image</th>
                    <th>Product</th>
                    <th>SKU / Barcode</th>
                    <th>Category</th>
                    <th>Unit</th>
                    <th>Cost</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th width="120">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td>
                        <?php if($product->image): ?>
                            <img src="<?php echo e(Storage::url($product->image)); ?>" alt="<?php echo e($product->name); ?>" class="product-img">
                        <?php else: ?>
                            <div class="product-img-placeholder"><i class="bi bi-image"></i></div>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <div style="font-weight:600; color:#111827;"><?php echo e($product->name); ?></div>
                        <?php if($product->description): ?>
                            <div style="font-size:12px; color:#9ca3af;"><?php echo e(Str::limit($product->description, 50)); ?></div>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <code style="background:#f3f4f6; padding:2px 7px; border-radius:4px; font-size:12px; display:block; margin-bottom:2px;"><?php echo e($product->sku); ?></code>
                        <?php if($product->barcode): ?>
                            <span style="font-size:11px; color:#9ca3af;"><i class="bi bi-upc-scan"></i> <?php echo e($product->barcode); ?></span>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <?php if($product->category): ?>
                            <span style="background:#e8f4f7; color:var(--pos-primary); padding:3px 10px; border-radius:20px; font-size:12px; font-weight:500;">
                                <?php echo e($product->category->name); ?>

                            </span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>

                    
                    <td style="font-size:13px; color:#6b7280;"><?php echo e(strtoupper($product->unit)); ?></td>

                    
                    <td style="font-size:13px; color:#6b7280;">$<?php echo e(number_format($product->cost_price, 2)); ?></td>

                    
                    <td style="font-weight:600; color:#111827;">$<?php echo e(number_format($product->sale_price, 2)); ?></td>

                    
                    <td>
                        <?php $status = $product->stock_status; ?>
                        <div style="font-weight:700; font-size:15px; color:#111827;"><?php echo e($product->stock_quantity); ?></div>
                        <span class="stock-badge <?php echo e($status === 'in_stock' ? 'stock-in' : ($status === 'low_stock' ? 'stock-low' : 'stock-out')); ?>">
                            <?php echo e($product->stock_status_label); ?>

                        </span>
                    </td>

                    
                    <td>
                        <?php if($product->is_active): ?>
                            <span class="badge badge-active rounded-pill px-3 py-1"><i class="bi bi-circle-fill me-1" style="font-size:8px;"></i>Active</span>
                        <?php else: ?>
                            <span class="badge badge-inactive rounded-pill px-3 py-1"><i class="bi bi-circle me-1" style="font-size:8px;"></i>Inactive</span>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <div class="d-flex gap-1">
                            <a href="<?php echo e(route('admin.products.edit', $product)); ?>"
                               class="btn btn-sm btn-outline-secondary" style="border-radius:7px;" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('admin.products.toggle-status', $product)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-sm <?php echo e($product->is_active ? 'btn-outline-warning' : 'btn-outline-success'); ?>"
                                    style="border-radius:7px;" title="<?php echo e($product->is_active ? 'Deactivate' : 'Activate'); ?>">
                                    <i class="bi <?php echo e($product->is_active ? 'bi-toggle-on' : 'bi-toggle-off'); ?>"></i>
                                </button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>"
                                onsubmit="return confirm('Soft-delete product \'<?php echo e(addslashes($product->name)); ?>\'?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger" style="border-radius:7px;" title="Delete">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <?php if($products->hasPages()): ?>
            <div class="px-4 py-3 border-top d-flex justify-content-between align-items-center">
                <p class="text-muted mb-0" style="font-size:13px;">
                    Showing <?php echo e($products->firstItem()); ?>–<?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?> products
                </p>
                <?php echo e($products->links('vendor.pagination.bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    setTimeout(() => {
        document.querySelectorAll('.pos-alert').forEach(el => {
            el.style.transition = 'opacity .4s';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 400);
        });
    }, 4000);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/admin/products/index.blade.php ENDPATH**/ ?>