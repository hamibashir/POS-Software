
<?php $__env->startSection('title', 'New Stock Adjustment'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .adj-card { background:#fff; border:1px solid #e5e7eb; border-radius:12px; overflow:hidden; max-width:680px; margin:0 auto; }
    .adj-header { background:#f9fafb; border-bottom:1px solid #e5e7eb; padding:14px 22px; font-size:11px; font-weight:700; color:#6b7280; text-transform:uppercase; letter-spacing:1px; display:flex; align-items:center; gap:8px; }
    .adj-body { padding:24px 22px; }
    .fg { display:flex; flex-direction:column; gap:6px; margin-bottom:18px; }
    .fg label { font-size:13px; font-weight:600; color:#374151; }
    .fg label .req { color:#ef4444; }
    .fg .hint { font-size:12px; color:#9ca3af; }
    .type-toggle { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
    .type-opt { position:relative; }
    .type-opt input[type=radio] { position:absolute; opacity:0; width:0; height:0; }
    .type-opt label {
        display:flex; flex-direction:column; align-items:center; gap:6px;
        border:2px solid #e5e7eb; border-radius:12px; padding:16px 12px;
        cursor:pointer; transition:all .15s; text-align:center;
    }
    .type-opt input:checked + label { border-color:var(--pos-primary); background:var(--pos-primary-lt); }
    .type-opt .ico { font-size:28px; }
    .type-opt .lbl { font-size:14px; font-weight:700; }
    .type-opt .sub { font-size:11px; color:#9ca3af; }
    .stock-preview {
        background:#f9fafb; border:1px solid #e5e7eb; border-radius:10px;
        padding:14px 18px; display:flex; justify-content:space-between; align-items:center;
        margin-bottom:18px; font-size:14px;
    }
    .stock-preview .current { font-size:22px; font-weight:800; color:#111827; }
    .stock-preview .arrow { font-size:22px; color:#9ca3af; }
    .stock-preview .result { font-size:22px; font-weight:800; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const products = <?php echo json_encode($products, 15, 512) ?>;

function onProductChange() {
    const pid = parseInt(document.getElementById('product_id').value);
    const p = products.find(x => x.id === pid);
    if (p) {
        document.getElementById('currentStock').textContent = p.stock_quantity;
        document.getElementById('stockUnit').textContent = p.unit.toUpperCase();
        document.getElementById('preview').style.display = 'flex';
    } else {
        document.getElementById('preview').style.display = 'none';
    }
    updatePreview();
}

function updatePreview() {
    const pid  = parseInt(document.getElementById('product_id').value);
    const p    = products.find(x => x.id === pid);
    const qty  = parseInt(document.getElementById('quantity').value) || 0;
    const type = document.querySelector('input[name="type"]:checked')?.value;
    if (!p) return;

    const current = p.stock_quantity;
    const result  = type === 'adjustment_in' ? current + qty : current - qty;
    const el      = document.getElementById('resultStock');
    el.textContent = result;
    el.style.color = result < 0 ? '#991b1b' : (type === 'adjustment_in' ? '#065f46' : '#b45309');
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input[name="type"]').forEach(r => r.addEventListener('change', updatePreview));
    document.getElementById('quantity').addEventListener('input', updatePreview);
    document.getElementById('product_id').addEventListener('change', onProductChange);
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center mb-3">
    <nav style="font-size:13px;color:#9ca3af;">
        <a href="<?php echo e(route('admin.stock.index')); ?>" style="color:var(--pos-primary);text-decoration:none;font-weight:600;">
            <i class="bi bi-arrow-left"></i> Stock Adjustments
        </a>
        <span class="mx-2">·</span>
        <span style="color:#374151;font-weight:600;">New Adjustment</span>
    </nav>
</div>

<?php if($errors->any()): ?>
<div class="pos-alert pos-alert-error mb-3" style="max-width:680px;margin:0 auto 16px;">
    <i class="bi bi-exclamation-triangle-fill"></i>
    <div>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div><?php echo e($e); ?></div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<div class="adj-card">
    <div class="adj-header"><i class="bi bi-sliders"></i> Manual Stock Adjustment</div>
    <div class="adj-body">

        <form method="POST" action="<?php echo e(route('admin.stock.store')); ?>">
            <?php echo csrf_field(); ?>

            
            <div class="fg">
                <label for="product_id">Product <span class="req">*</span></label>
                <select id="product_id" name="product_id" class="pos-input" required onchange="onProductChange()">
                    <option value="">— Select a product —</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" <?php echo e(old('product_id') == $p->id ? 'selected' : ''); ?>>
                            <?php echo e($p->name); ?> — <?php echo e($p->sku); ?> (Stock: <?php echo e($p->stock_quantity); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="stock-preview" id="preview" style="display:none;">
                <div>
                    <div style="font-size:11px;text-transform:uppercase;letter-spacing:.7px;color:#9ca3af;font-weight:600;">Current Stock</div>
                    <div class="current"><span id="currentStock">0</span> <span style="font-size:13px;font-weight:500;" id="stockUnit">PCS</span></div>
                </div>
                <div class="arrow">→</div>
                <div>
                    <div style="font-size:11px;text-transform:uppercase;letter-spacing:.7px;color:#9ca3af;font-weight:600;">After Adjustment</div>
                    <div class="result" id="resultStock" style="color:#065f46;">0</div>
                </div>
            </div>

            
            <div class="fg">
                <label>Adjustment Type <span class="req">*</span></label>
                <div class="type-toggle">
                    <div class="type-opt">
                        <input type="radio" id="type_in" name="type" value="adjustment_in"
                            <?php echo e(old('type', 'adjustment_in') === 'adjustment_in' ? 'checked' : ''); ?>>
                        <label for="type_in">
                            <span class="ico">⬆️</span>
                            <span class="lbl" style="color:#065f46;">Stock In</span>
                            <span class="sub">Add units (damaged return,<br>correction, found stock)</span>
                        </label>
                    </div>
                    <div class="type-opt">
                        <input type="radio" id="type_out" name="type" value="adjustment_out"
                            <?php echo e(old('type') === 'adjustment_out' ? 'checked' : ''); ?>>
                        <label for="type_out">
                            <span class="ico">⬇️</span>
                            <span class="lbl" style="color:#991b1b;">Stock Out</span>
                            <span class="sub">Remove units (damaged, lost,<br>expired, correction)</span>
                        </label>
                    </div>
                </div>
            </div>

            
            <div class="fg">
                <label for="quantity">Quantity <span class="req">*</span></label>
                <input type="number" id="quantity" name="quantity" class="pos-input"
                    min="1" value="<?php echo e(old('quantity', 1)); ?>" required
                    style="max-width:180px;">
                <div class="hint">Enter the number of units to add or remove.</div>
            </div>

            
            <div class="fg">
                <label for="notes">Reason / Notes <span class="req">*</span></label>
                <textarea id="notes" name="notes" class="pos-input" rows="3" required
                    placeholder="e.g. Damaged goods written off, stock count correction, returned item…"><?php echo e(old('notes')); ?></textarea>
            </div>

            <div style="display:flex;gap:10px;margin-top:4px;">
                <button type="submit" class="btn-pos">
                    <i class="bi bi-check-circle"></i> Save Adjustment
                </button>
                <a href="<?php echo e(route('admin.stock.index')); ?>" class="btn-pos-outline text-decoration-none">
                    Cancel
                </a>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/admin/stock/create.blade.php ENDPATH**/ ?>