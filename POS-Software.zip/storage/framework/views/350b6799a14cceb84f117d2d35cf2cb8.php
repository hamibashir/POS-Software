

<?php $__env->startSection('title', 'Sale ' . $sale->invoice_number); ?>

<?php $__env->startPush('styles'); ?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');

    .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }
    @media (max-width:768px) { .detail-grid { grid-template-columns: 1fr; } }

    .detail-card {
        background: #fff; border: 1px solid #e5e7eb; border-radius: 12px;
        overflow: hidden;
    }
    .detail-card-header {
        background: #f9fafb; border-bottom: 1px solid #e5e7eb;
        padding: 12px 18px;
        font-size: 11px; font-weight: 700; color: #6b7280;
        text-transform: uppercase; letter-spacing: 1px;
        display: flex; align-items: center; gap: 8px;
    }
    .detail-card-body { padding: 18px; }

    .info-row {
        display: flex; justify-content: space-between; align-items: flex-start;
        padding: 8px 0; border-bottom: 1px solid #f9fafb; font-size: 14px;
    }
    .info-row:last-child { border-bottom: none; }
    .info-row .lbl { color: #9ca3af; font-size: 12px; font-weight: 500; }
    .info-row .val { font-weight: 600; color: #111827; text-align: right; }

    .inv-hero {
        font-family: 'JetBrains Mono', monospace;
        font-size: 22px; font-weight: 700;
        color: #1d4ed8;
        background: #eff6ff; border-radius: 8px;
        padding: 8px 16px; display: inline-block;
    }

    .pay-cash { background:#d1fae5; color:#065f46; }
    .pay-card { background:#ede9fe; color:#5b21b6; }
    .pay-badge { display:inline-flex; align-items:center; gap:4px; border-radius:20px; padding:4px 12px; font-size:12px; font-weight:700; }

    .status-completed { background:#d1fae5; color:#065f46; }
    .status-voided    { background:#fee2e2; color:#991b1b; }
    .status-badge     { border-radius:20px; padding:4px 12px; font-size:12px; font-weight:700; }

    /* Items table */
    .items-detail-table { width:100%; border-collapse:collapse; }
    .items-detail-table thead th {
        background:#f9fafb; font-size:11px; font-weight:700;
        text-transform:uppercase; letter-spacing:.6px; color:#6b7280;
        padding:10px 16px; border-bottom:1px solid #e5e7eb;
    }
    .items-detail-table tbody td {
        padding:14px 16px; font-size:14px; color:#374151;
        border-bottom:1px solid #f9fafb; vertical-align:middle;
    }
    .items-detail-table tbody tr:last-child td { border-bottom:none; }
    .items-detail-table tfoot td {
        padding:10px 16px; font-size:13px; border-top:1px solid #e5e7eb;
    }
    .item-name { font-weight:600; color:#111827; }
    .item-sku  { font-size:11px; color:#9ca3af; font-family:'JetBrains Mono', monospace; }

    .t-row-foot { display:flex; justify-content:space-between; padding:6px 16px; font-size:13px; color:#374151; }
    .t-row-foot.discount { color:#10b981; }
    .t-row-foot.grand    { font-size:17px; font-weight:800; color:#111827; border-top:2px solid #111827; padding-top:10px; margin-top:4px; }
    .t-row-foot.change   { background:#d1fae5; border-radius:8px; margin:6px 16px; padding:8px 16px; font-weight:700; color:#065f46; font-size:14px; }

    .action-strip {
        display: flex; gap: 10px; margin-bottom: 24px; flex-wrap: wrap;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <nav style="font-size:13px; color:#9ca3af;">
        <a href="<?php echo e(route('admin.sales.index')); ?>" style="color:var(--pos-primary); text-decoration:none; font-weight:600;">
            <i class="bi bi-arrow-left"></i> Sales History
        </a>
        <span class="mx-2">·</span>
        <span style="color:#374151; font-weight:600;"><?php echo e($sale->invoice_number); ?></span>
    </nav>

    <div class="action-strip mb-0">
        
        <a href="<?php echo e(route('cashier.pos.receipt', $sale)); ?>"
           target="_blank" rel="noopener"
           class="btn-pos-outline text-decoration-none">
            <i class="bi bi-eye"></i> View Receipt
        </a>
        
        <a href="<?php echo e(route('cashier.pos.receipt', $sale)); ?>?print=1"
           target="_blank" rel="noopener"
           class="btn-pos text-decoration-none">
            <i class="bi bi-printer"></i> Reprint Receipt
        </a>
    </div>
</div>

<div class="mb-3">
    <div class="inv-hero"><?php echo e($sale->invoice_number); ?></div>
    <span class="status-badge <?php echo e($sale->status === 'completed' ? 'status-completed' : 'status-voided'); ?> ms-2">
        <?php echo e(ucfirst($sale->status)); ?>

    </span>
</div>


<div class="detail-grid">

    
    <div class="detail-card">
        <div class="detail-card-header"><i class="bi bi-info-circle"></i> Sale Information</div>
        <div class="detail-card-body">
            <div class="info-row">
                <span class="lbl">Date & Time</span>
                <span class="val">
                    <?php echo e($sale->created_at->format('d M Y')); ?><br>
                    <span style="color:#9ca3af; font-weight:400; font-size:12px;"><?php echo e($sale->created_at->format('g:i:s A')); ?></span>
                </span>
            </div>
            <div class="info-row">
                <span class="lbl">Cashier</span>
                <span class="val"><?php echo e($sale->user?->name ?? '—'); ?></span>
            </div>
            <div class="info-row">
                <span class="lbl">Payment Method</span>
                <span class="val">
                    <span class="pay-badge <?php echo e($sale->payment_method === 'cash' ? 'pay-cash' : 'pay-card'); ?>">
                        <?php echo e($sale->payment_method === 'cash' ? '💵' : '💳'); ?>

                        <?php echo e(strtoupper($sale->payment_method)); ?>

                    </span>
                </span>
            </div>
            <?php if($sale->notes): ?>
            <div class="info-row">
                <span class="lbl">Notes</span>
                <span class="val" style="font-weight:400; color:#6b7280; text-align:right; max-width:60%;"><?php echo e($sale->notes); ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="detail-card">
        <div class="detail-card-header"><i class="bi bi-person"></i> Customer Details</div>
        <div class="detail-card-body">
            <div class="info-row">
                <span class="lbl">Name</span>
                <span class="val"><?php echo e($sale->customer_name ?? 'Walk-in Customer'); ?></span>
            </div>
            <div class="info-row">
                <span class="lbl">Phone</span>
                <span class="val"><?php echo e($sale->customer_phone ?? '—'); ?></span>
            </div>
            <div class="info-row">
                <span class="lbl">Total Items</span>
                <span class="val"><?php echo e($sale->items->sum('quantity')); ?> pcs (<?php echo e($sale->items->count()); ?> lines)</span>
            </div>
            <div class="info-row">
                <span class="lbl">Paid Amount</span>
                <span class="val" style="color:#10b981;">$<?php echo e(number_format($sale->paid_amount, 2)); ?></span>
            </div>
            <?php if($sale->change_amount > 0): ?>
            <div class="info-row">
                <span class="lbl">Change Given</span>
                <span class="val">$<?php echo e(number_format($sale->change_amount, 2)); ?></span>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="detail-card mb-4">
    <div class="detail-card-header"><i class="bi bi-list-ul"></i> Items Sold (<?php echo e($sale->items->count()); ?>)</div>

    <table class="items-detail-table">
        <thead>
            <tr>
                <th style="text-align:left; width:40%;">Product</th>
                <th style="text-align:right;">Unit Price</th>
                <th style="text-align:right;">Qty</th>
                <th style="text-align:right;">Discount</th>
                <th style="text-align:right;">Line Total</th>
                <th style="text-align:right;">Cost</th>
                <th style="text-align:right;">Margin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $cost   = $item->cost_price * $item->quantity;
                $margin = $item->total_price > 0 ? (($item->total_price - $cost) / $item->total_price) * 100 : 0;
            ?>
            <tr>
                <td>
                    <div class="item-name"><?php echo e($item->product_name); ?></div>
                    <div class="item-sku"><?php echo e($item->product_sku); ?> · <?php echo e(strtoupper($item->product_unit)); ?></div>
                </td>
                <td style="text-align:right;">$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td style="text-align:right; font-weight:600;"><?php echo e($item->quantity); ?></td>
                <td style="text-align:right; color:#10b981;">
                    <?php echo e($item->discount_amount > 0 ? '−$' . number_format($item->discount_amount, 2) : '—'); ?>

                </td>
                <td style="text-align:right; font-weight:700; color:#111827;">$<?php echo e(number_format($item->total_price, 2)); ?></td>
                <td style="text-align:right; color:#9ca3af; font-size:12px;">$<?php echo e(number_format($cost, 2)); ?></td>
                <td style="text-align:right;">
                    <span style="font-size:12px; font-weight:700;
                        color:<?php echo e($margin >= 20 ? '#065f46' : ($margin >= 10 ? '#92400e' : '#991b1b')); ?>;">
                        <?php echo e(number_format($margin, 1)); ?>%
                    </span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <div style="border-top:1.5px dashed #e5e7eb; padding: 16px 0 8px;">
        <div class="t-row-foot">
            <span>Subtotal (<?php echo e($sale->items->sum('quantity')); ?> items)</span>
            <span>$<?php echo e(number_format($sale->subtotal, 2)); ?></span>
        </div>
        <?php if($sale->discount_amount > 0): ?>
        <div class="t-row-foot discount">
            <span>Discount</span>
            <span>−$<?php echo e(number_format($sale->discount_amount, 2)); ?></span>
        </div>
        <?php endif; ?>
        <?php if($sale->tax_amount > 0): ?>
        <div class="t-row-foot">
            <span>Tax</span>
            <span>$<?php echo e(number_format($sale->tax_amount, 2)); ?></span>
        </div>
        <?php endif; ?>
        <div class="t-row-foot grand">
            <span>TOTAL</span>
            <span>$<?php echo e(number_format($sale->total_amount, 2)); ?></span>
        </div>
        <?php if($sale->change_amount > 0): ?>
        <div class="t-row-foot change">
            <span>💵 Change Due</span>
            <span>$<?php echo e(number_format($sale->change_amount, 2)); ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/admin/sales/show.blade.php ENDPATH**/ ?>