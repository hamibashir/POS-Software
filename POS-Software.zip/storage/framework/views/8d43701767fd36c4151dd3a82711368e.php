

<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-hero d-flex align-items-start justify-content-between">
    <div>
        <h1><i class="bi bi-pencil-square me-2" style="color:var(--pos-primary)"></i>Edit Product</h1>
        <p>
            <a href="<?php echo e(route('admin.products.index')); ?>" style="color:var(--pos-primary); text-decoration:none; font-size:13px;">
                <i class="bi bi-arrow-left"></i> Back to Products
            </a>
            &nbsp;&middot;&nbsp;
            <span style="font-size:13px; color:#9ca3af;">Editing: <strong style="color:#374151;"><?php echo e($product->name); ?></strong></span>
        </p>
    </div>
</div>

<form method="POST" action="<?php echo e(route('admin.products.update', $product)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('admin.products._form', ['submitLabel' => 'Update Product'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\Documents\Github\POS-Software\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>